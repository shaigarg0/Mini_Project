<?php
	$connection = mysql_connect("localhost","root","") or die("cant connect to database");
	$db = mysql_select_db("db1", $connection) or die(mysql_error());
	
	$rno=$_REQUEST["rno"];
	$name=$_REQUEST["name"];
	$address=$_REQUEST["address"];
	$gender=$_REQUEST["gender"];
	$course=$_REQUEST["course"];
	
	
	$sql_update ="UPDATE test SET rollno = '$rno',name = '$name',address = '$address',gender = '$gender',course = '$course' WHERE rollno='$rno'";
	$result=mysql_query($sql_update);
	echo "Record Sucessfully Updated";
?>

