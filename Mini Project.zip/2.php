<?php
$connection = mysql_connect("localhost","root","") or die("cant connect to database");
$db = mysql_select_db("db1", $connection) or die(mysql_error());

$rno=$_REQUEST["rno"];
$name=$_REQUEST["name"];
$address=$_REQUEST["address"];
$gender=$_REQUEST["gender"];
$course=$_REQUEST["course"];

$sql_insert="INSERT INTO test(rollno,name,address,gender,course)VALUES(
						'".$rno."',
						'".$name."',
						'".$address."',
						'".$gender."',
						'".$course."')";
$result=mysql_query($sql_insert);
echo "Record Sucessfully Inserted";
?>

