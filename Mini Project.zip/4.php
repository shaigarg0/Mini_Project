<?php
$connection = mysql_connect("localhost","root","") or die("cant connect to database");
$db = mysql_select_db("db1", $connection) or die(mysql_error());

$rno=$_REQUEST["rno"];
$sql_search="SELECT * FROM test WHERE rollno='".$rno."'";
$result=mysql_query($sql_search);
$total = mysql_num_rows($result);
if($total>0)
{
	$fetch = mysql_fetch_array($result);
	?>
	<center>
	<form name="myform" action="5.php" method="post" onSubmit="return validate()">
	<h3>Student Edit/Update Form</h3>
	<table border="1" cellpadding="0" cellspacing="0" width="25%">
	<tr>
	<td>

	<table border="0">
	<tr>
	<td><b>Roll No:</b></td>
	<td><?php echo $fetch["rollno"] ?></td>
	</tr>
	
	<tr>
	<td><b>Name:</b></td>
	<td><?php echo $fetch["name"]?></td> <!--ucwords()-->
	</tr>	
	
	<tr>
	<td><b>address:</b></td>
	<td><?php echo $fetch["address"]?></td><!--ucwords()-->
	</tr>
	
	<tr><td><b>Gender:</b></td>
	<td><?php echo $fetch["gender"]?></td><!--ucwords()-->
	</tr>	
	
	<tr><td><b>course:</b></td>
	<td><?php echo $fetch["course"]?></td><!--ucwords()-->
	</tr>
	</table>
	
	</td>
	</tr>
	</table>	
	</form>
	</center>
	<?php	
}
else
{
	echo "Record Not Found...Sorry";
}
?>