<?php
$connection = mysql_connect("localhost","root","") or die("cant connect to database");
$db = mysql_select_db("db1", $connection) or die(mysql_error());

$rno=$_REQUEST["rno"];
$sql_search="SELECT * FROM test WHERE rollno='".$rno."'";
$result=mysql_query($sql_search);
$total = mysql_num_rows($result);


if($total>0)
{
	$fetch = mysql_fetch_array($result);
	?>
	<center>
	<form name="myform" action="7.php" method="post" onSubmit="return validate()">
	<h3>Student Edit/Update Form</h3>
	<table border="1" cellpadding="0" cellspacing="0">
	<tr>
	<td>

	<table border="0">
	<tr>
	<td><b>Roll No:</b></td>
	<td>
	<input type="text" name="rno" value="<?php echo $fetch["rollno"] ?>"readonly="readonly">
	</td>
	</tr>
	
	<tr>
	<td><b>Name:</b></td>
	<td>
	<input type="text" name="name" value="<?php echo $fetch["name"]?>">
	</td>
	</tr>	
	
	<tr>
	<td><b>address:</b></td>
	<td><input type="text" name="address" value="<?php echo $fetch["address"]?>"></td>
	</tr>
	
	<tr><td><b>Gender:</b></td>
	<td>
	<?php
	if($fetch["gender"]=="male")
	{
	?>	
		<input type="radio" name="gender" value="male" checked="checked">Male
		<input type="radio" name="gender" value="female">Female
	<?php
	}
	?>	
	<?php
	if($fetch["gender"]=="female")
	{
	?>
		<input type="radio" name="gender" value="male">Male
		<input type="radio" name="gender" value="female" checked="checked">Female
	<?php
	}
	?>	
	</td>
	</tr>	
	
	<tr><td><b>course:</b></td>
	<td>
	<select name="course">
	<?php
	if($fetch["course"]=="mca")
	{
	?>
		<option value="mca" selected>MCA</option>
		<option value="mba">MBA</option>
		<option value="btech">B-Tech</option>
	<?php	
	}
	if($fetch["course"]=="mba")
	{
	?>
		<option value="mca">MCA</option>
		<option value="mba" selected>MBA</option>
		<option value="btech">B-Tech</option>
	<?php	
	}
	if($fetch["course"]=="btech")
	{
	?>
		<option value="mca">MCA</option>
		<option value="mba">MBA</option>
		<option value="btech" selected>B-Tech</option>
	<?php	
	}
	?>
	</select>
	</td>
	</tr>
		
	<tr>
	<td colspan="2"><input type="submit" value="Update"></td>
	</tr>
	</table>
	
	</td>
	</tr>
	</table>	
	
	</form>
	</center>
	<?php	
}
else
{
	echo "Record Not Found...Sorry";
}
?>