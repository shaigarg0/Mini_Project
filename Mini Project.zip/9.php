<?php
	$connection = mysql_connect("localhost","root","") or die("cant connect to database");
	$db = mysql_select_db("db1", $connection) or die(mysql_error());
	
	$rno=$_REQUEST["rno"];
	
	
	$sql_delete ="DELETE FROM test WHERE rollno='$rno'";
	$result=mysql_query($sql_delete);
	echo "Record Sucessfully Deleted";
?>